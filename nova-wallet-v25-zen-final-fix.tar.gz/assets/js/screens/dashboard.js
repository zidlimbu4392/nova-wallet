/* ==========================================================================
   Nova Wallet — Dashboard screen
   ========================================================================== */

window.NovaScreens = window.NovaScreens || {};

window.NovaScreens.dashboard = (function () {
  "use strict";
  const UI = window.NovaUI, S = window.NovaStore, D = window.NovaData;
  const Screens = window.NovaScreens;

  function greet() {
    const h = new Date().getHours();
    if (h < 6) return "Good night";
    if (h < 12) return "Good morning";
    if (h < 18) return "Good afternoon";
    return "Good evening";
  }

  // Средневзвешенное изменение портфеля за 24ч
  function portfolioDelta() {
    let weighted = 0, total = 0;
    S.state.tokens.forEach(t => {
      const f = t.balance * t.price;
      weighted += f * t.change24;
      total += f;
    });
    return total ? weighted / total : 0;
  }

  function renderHero() {
    const total = S.totalFiat();
    const parts = UI.fmtNum(total, 2).split('.');
    const intPart = parts[0];
    const centsPart = parts.length > 1 ? '.' + parts[1] : '';
    
    let username = S.state.wallet.name;
    let avatarHtml = `<div style="width:20px;height:20px;border-radius:50%;background:#5b5bf6;color:#fff;display:grid;place-items:center;font-size:11px;line-height:1;">${S.state.wallet.avatarInitial}</div>`;

    const tgUser = window.Telegram && window.Telegram.WebApp && window.Telegram.WebApp.initDataUnsafe && window.Telegram.WebApp.initDataUnsafe.user;
    if (tgUser) {
      username = tgUser.first_name || username;
      if (tgUser.photo_url) {
        avatarHtml = `<img src="${tgUser.photo_url}" style="width:20px;height:20px;border-radius:50%;object-fit:cover;">`;
      }
    }

    return `
      <div class="zen-top">
        <div class="zen-head">
          <span style="color:var(--text-secondary);font-weight:600;font-size:15px">Balance</span>
          <span class="zen-badge">
             ${avatarHtml}
             ${username}
          </span>
        </div>
        <div class="zen-balance" id="dashBalance">
          <span class="zen-cur">$</span><span class="zen-int">${intPart}</span><span class="zen-cents">${centsPart}</span>
        </div>
        <div class="zen-cards">
          <div class="z-card">
            <div class="z-card-label"><span class="z-ico" style="background:#fce4ec;color:#d81b60;display:grid;place-items:center;font-size:12px;">✿</span> Invest</div>
            <div class="z-card-val">$ 70 850</div>
          </div>
          <div class="z-card">
            <div class="z-card-label"><span class="z-ico" style="background:#fff3e0;color:#ef6c00;display:grid;place-items:center;font-size:12px;">👤</span> Shared</div>
            <div class="z-card-val">$ 1 200.50</div>
          </div>
          <div class="z-card" style="min-width:80px;align-items:center;justify-content:center;">
            <div class="z-card-label">Loans</div>
            <div class="z-card-val" style="margin-top:4px;">→</div>
          </div>
        </div>
      </div>`;
  }

  function renderActions() {
    return `
      <div class="zen-middle">
        <button class="zen-act" data-act="send">
          <img src="assets/icons/paper-plane.svg" /> Send
        </button>
        <button class="zen-act" data-act="receive">
          <img src="assets/icons/down-right.svg" /> Receive
        </button>
        <button class="zen-act" data-act="swap">
          <img src="assets/icons/shuffle.svg" /> Swap
        </button>
      </div>`;
  }

  function renderTokens() {
    const rows = S.state.tokens.map(t => {
      const f = S.tokenFiat(t);
      const up = t.change24 >= 0;
      return `
        <div class="list-row tap zen-row" data-token="${t.id}">
          ${UI.tokenIcon(t)}
          <div class="row-main">
            <div class="sym" style="font-size: 16px; font-weight: 650; letter-spacing: -0.01em; margin-bottom: 2px;">${t.name}</div>
            <div class="sub" style="font-size: 13px; display: flex; gap: 6px;">
               <span>$${UI.fmtNum(t.price, 3)}</span>
               <span class="delta ${up ? "delta-up" : "delta-down"}">${up ? "+" : ""}${UI.fmtPct(t.change24)}</span>
            </div>
          </div>
          <div class="row-trail" style="display: flex; flex-direction: column; align-items: flex-end; gap: 2px; flex-shrink: 0;">
            <div class="sym t-num" style="font-size: 15px; font-weight: 650;">${UI.fmtTokenAmt(t.balance)} ${t.symbol.toUpperCase()}</div>
            <div class="sub t-num" style="font-size: 13px;">${UI.fmtUSD(f)}</div>
          </div>
        </div>`;
    }).join("");
    return `
      <div class="zen-bottom">
        <div class="zen-bottom-head">
          <span>Assets</span>
          <a href="#">View all ›</a>
        </div>
        <div class="zen-filter">
          <span class="zf-pill active">All</span>
          <span class="zf-pill">Crypto</span>
          <span class="zf-pill">Fiat</span>
        </div>
        <div class="list stagger">${rows}</div>
      </div>`;
  }

  function render() {
    if (S.state.loading) {
      return `<div class="screen flex" style="align-items:center;justify-content:center;height:100%"><div class="spinner"></div></div>`;
    }
    return `
      <div class="zen-screen stagger">
        ${renderHero()}
        ${renderActions()}
        ${renderTokens()}
      </div>`;
  }

  function mount(root) {
    // Анимация счётчика баланса
    const balEl = root.querySelector("#dashBalance");
    if (balEl) UI.countUp(balEl, S.totalFiat(), { dur: 900, fmt: v => UI.fmtUSD(v, { max: 2 }) });

    // Тап по hero-карточке → История (push)
    root.querySelector(".dash-hero")?.addEventListener("click", () => {
      UI.push({
        title: "",
        render: () => Screens.activity.render(),
        onMount: (view) => Screens.activity.mount(view)
      });
    });

    // Действия
    root.querySelectorAll("[data-act]").forEach(el => {
      el.addEventListener("click", () => {
        const a = el.getAttribute("data-act");
        if (a === "send") window.NovaScreens.send.open();
        else if (a === "receive") window.NovaScreens.receive.open();
        else if (a === "swap") window.NovaScreens.swap.open();
      });
    });

    // Тап по токену → детали токена (push)
    root.querySelectorAll("[data-token]").forEach(el => {
      el.addEventListener("click", () => {
        const id = el.getAttribute("data-token");
        Screens.token.open(id);
      });
    });
  }

  return { render, mount };
})();

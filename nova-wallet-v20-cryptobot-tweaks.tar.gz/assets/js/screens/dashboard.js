/* ==========================================================================
   Nova Wallet — Dashboard screen
   ========================================================================== */

window.NovaScreens = window.NovaScreens || {};

window.NovaScreens.dashboard = (function () {
  "use strict";
  const UI = window.NovaUI, S = window.NovaStore, D = window.NovaData;
  const Screens = window.NovaScreens;

  function greet() {
    const h = new Date().getHours();
    if (h < 6) return "Good night";
    if (h < 12) return "Good morning";
    if (h < 18) return "Good afternoon";
    return "Good evening";
  }

  // Средневзвешенное изменение портфеля за 24ч
  function portfolioDelta() {
    let weighted = 0, total = 0;
    S.state.tokens.forEach(t => {
      const f = t.balance * t.price;
      weighted += f * t.change24;
      total += f;
    });
    return total ? weighted / total : 0;
  }

  function renderHero() {
    const total = S.totalFiat();
    return `
      <div class="dash-hero" style="text-align: center; padding: 32px 16px 16px; background: transparent; box-shadow: none;">
        <div class="dash-balance t-num" id="dashBalance" style="font-size: 40px; font-weight: 700; letter-spacing: -0.02em; margin-bottom: 6px;">$0</div>
        <div class="dash-greet" style="color: var(--text-secondary); font-size: 14px; font-weight: 500;">Total balance in USD</div>
      </div>`;
  }

  function renderActions() {
    return `
      <div class="dash-actions" style="display: flex; justify-content: center; gap: 32px; padding: 16px 16px 32px;">
        <button class="act-btn-circ" data-act="receive">
          <span class="act-ico-circ" style="background: var(--accent); color: #fff;"><img src="assets/icons/down-right.svg" alt="" style="filter: brightness(0) invert(1);" /></span>
          <span class="act-label-circ">Receive</span>
        </button>
        <button class="act-btn-circ" data-act="send">
          <span class="act-ico-circ" style="background: var(--accent); color: #fff;"><img src="assets/icons/paper-plane.svg" alt="" style="filter: brightness(0) invert(1);" /></span>
          <span class="act-label-circ">Send</span>
        </button>
        <button class="act-btn-circ" data-act="swap">
          <span class="act-ico-circ" style="background: var(--accent); color: #fff;"><img src="assets/icons/shuffle.svg" alt="" style="filter: brightness(0) invert(1);" /></span>
          <span class="act-label-circ">Swap</span>
        </button>
      </div>`;
  }

  function renderTokens() {
    const rows = S.state.tokens.map(t => {
      const f = S.tokenFiat(t);
      const up = t.change24 >= 0;
      return `
        <div class="list-row tap" data-token="${t.id}">
          ${UI.tokenIcon(t)}
          <div class="row-main">
            <div class="sym" style="font-size: 16px; font-weight: 650; letter-spacing: -0.01em; margin-bottom: 2px;">${t.name}</div>
            <div class="sub" style="font-size: 13px; display: flex; gap: 6px;">
               <span>$${UI.fmtNum(t.price, 3)}</span>
               <span class="delta ${up ? "delta-up" : "delta-down"}">${up ? "+" : ""}${UI.fmtPct(t.change24)}</span>
            </div>
          </div>
          <div class="row-trail" style="display: flex; flex-direction: column; align-items: flex-end; gap: 2px; flex-shrink: 0;">
            <div class="sym t-num" style="font-size: 15px; font-weight: 650;">${UI.fmtTokenAmt(t.balance)} ${t.symbol.toUpperCase()}</div>
            <div class="sub t-num" style="font-size: 13px;">${UI.fmtUSD(f)}</div>
          </div>
        </div>`;
    }).join("");
    return `
      <div class="section-head">
        <span class="t-caption">Мои активы</span>
      </div>
      <div class="list stagger">${rows}</div>`;
  }

  function render() {
    if (S.state.loading) {
      return `<div class="screen flex" style="align-items:center;justify-content:center;height:100%"><div class="spinner"></div></div>`;
    }
    return `
      <div class="screen stagger">
        ${renderHero()}
        ${renderActions()}
        ${renderTokens()}
      </div>`;
  }

  function mount(root) {
    // Анимация счётчика баланса
    const balEl = root.querySelector("#dashBalance");
    if (balEl) UI.countUp(balEl, S.totalFiat(), { dur: 900, fmt: v => UI.fmtUSD(v, { max: 2 }) });

    // Тап по hero-карточке → История (push)
    root.querySelector(".dash-hero")?.addEventListener("click", () => {
      UI.push({
        title: "",
        render: () => Screens.activity.render(),
        onMount: (view) => Screens.activity.mount(view)
      });
    });

    // Действия
    root.querySelectorAll("[data-act]").forEach(el => {
      el.addEventListener("click", () => {
        const a = el.getAttribute("data-act");
        if (a === "send") window.NovaScreens.send.open();
        else if (a === "receive") window.NovaScreens.receive.open();
        else if (a === "swap") window.NovaScreens.swap.open();
      });
    });

    // Тап по токену → детали токена (push)
    root.querySelectorAll("[data-token]").forEach(el => {
      el.addEventListener("click", () => {
        const id = el.getAttribute("data-token");
        Screens.token.open(id);
      });
    });
  }

  return { render, mount };
})();

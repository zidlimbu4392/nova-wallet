import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const user = await prisma.user.findUnique({
      where: { telegramId: 'demo_user' },
      include: {
        balances: {
          include: { token: true }
        },
        transactions: {
          orderBy: { createdAt: 'desc' },
          take: 20
        }
      }
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Map balances — matching data.js format exactly
    const balances = user.balances.map(b => ({
      id: b.token.id,
      symbol: b.token.symbol,
      name: b.token.name,
      balance: b.balance,
      price: b.token.priceUsd,
      change24: b.token.change24,
      icon: b.token.icon,
      color: b.token.color,
      glyph: b.token.glyph,
      chain: b.token.chain
    }));

    const totalBalance = balances.reduce((sum, b) => sum + (b.balance * b.price), 0);

    // Build tokenId → symbol map
    const allTokens = await prisma.token.findMany();
    const tokenMap: Record<string, any> = {};
    allTokens.forEach(t => { tokenMap[t.id] = t; });

    // Map transactions — matching data.js TXS format EXACTLY
    // activity.js expects: id, type (recv/send/swap/stake), token, amount (number),
    //                      fiat, time ("Today, 14:22"), status, from, to, hash, fee, rate, note
    const now = new Date();
    const formattedTxs = user.transactions.map(tx => {
      const tok = tx.tokenId ? tokenMap[tx.tokenId] : null;
      const symbol = tok?.symbol || '';

      // Format time like data.js: "Today, 14:22" or "Jun 20, 19:02"  
      const txDate = new Date(tx.createdAt);
      const isToday = txDate.toDateString() === now.toDateString();
      const yesterday = new Date(now);
      yesterday.setDate(yesterday.getDate() - 1);
      const isYesterday = txDate.toDateString() === yesterday.toDateString();
      
      const timeHM = txDate.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
      let dayPart: string;
      if (isToday) dayPart = 'Today';
      else if (isYesterday) dayPart = 'Yesterday';
      else dayPart = txDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

      const timeStr = `${dayPart}, ${timeHM}`;

      // Build token string: for swap "BTC→ETH", for others just "ETH"
      let tokenStr = symbol;
      if (tx.type === 'swap' && tx.note) {
        tokenStr = tx.note; // Already formatted as "BTC→ETH"
      }

      return {
        id: tx.id,
        type: tx.type,         // "recv", "send", "swap" — matching activity.js TYPE_META keys
        token: tokenStr,
        amount: tx.amount,     // number, NOT string — activity.js calls fmtTokenAmt(tx.amount)
        fiat: tx.fiatValue || 0,
        time: timeStr,
        status: tx.status,
        from: tx.fromAddr || undefined,
        to: tx.toAddress || undefined,
        hash: tx.hash || undefined,
        fee: tx.fee || undefined,
        rate: tx.type === 'swap' && tx.note ? `1 ${symbol} = ${(tok?.priceUsd || 0).toLocaleString()} USDT` : undefined,
        note: tx.note || undefined
      };
    });

    return NextResponse.json({
      user: {
        id: user.id,
        username: user.username,
        totalBalance
      },
      balances,
      transactions: formattedTxs
    });
  } catch (error) {
    console.error('Wallet API Error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

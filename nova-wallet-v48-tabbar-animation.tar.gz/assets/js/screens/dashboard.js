/* ==========================================================================
   Nova Wallet — Dashboard screen
   ========================================================================== */

window.NovaScreens = window.NovaScreens || {};

window.NovaScreens.dashboard = (function () {
  "use strict";
  const UI = window.NovaUI, S = window.NovaStore, D = window.NovaData;
  const Screens = window.NovaScreens;

  function greet() {
    const h = new Date().getHours();
    if (h < 6) return "Good night";
    if (h < 12) return "Good morning";
    if (h < 18) return "Good afternoon";
    return "Good evening";
  }

  // Средневзвешенное изменение портфеля за 24ч
  function portfolioDelta() {
    let weighted = 0, total = 0;
    S.state.tokens.forEach(t => {
      const f = t.balance * t.price;
      weighted += f * t.change24;
      total += f;
    });
    return total ? weighted / total : 0;
  }

  function renderHero() {
    const total = S.totalFiat();
    const parts = UI.fmtNum(total, 2).split('.');
    const intPart = parts[0];
    const centsPart = parts.length > 1 ? '.' + parts[1] : '';
    
    let username = S.state.wallet.name;
    let avatarHtml = `<div style="width:20px;height:20px;border-radius:50%;background:#5b5bf6;color:#fff;display:grid;place-items:center;font-size:11px;line-height:1;">${S.state.wallet.avatarInitial}</div>`;

    const tgUser = window.Telegram && window.Telegram.WebApp && window.Telegram.WebApp.initDataUnsafe && window.Telegram.WebApp.initDataUnsafe.user;
    if (tgUser) {
      username = tgUser.first_name || username;
      if (tgUser.photo_url) {
        avatarHtml = `<img src="${tgUser.photo_url}" style="width:20px;height:20px;border-radius:50%;object-fit:cover;">`;
      }
    }

    const delta = portfolioDelta();
    const isUp = delta >= 0;
    const deltaColor = isUp ? "var(--success, #34C759)" : "var(--danger, #ff3b30)";
    const deltaBg = isUp ? "rgba(52,199,89,0.12)" : "rgba(255,59,48,0.12)";
    const deltaSign = isUp ? "+" : "";
    const deltaBadgeHtml = `<span style="font-size:13px; font-weight:700; color:${deltaColor}; background:${deltaBg}; padding:2px 8px; border-radius:50px; margin-left:8px;">${deltaSign}${delta.toFixed(2)}%</span>`;

    const sparkData = isUp ? [60, 62, 60, 64, 68, 67, 71, 74, 76] : [76, 74, 71, 67, 68, 64, 60, 62, 60];
    const sparkColor = isUp ? "#34C759" : "#ff3b30";
    const sparklineHtml = UI.sparkline(sparkData, 320, 56, sparkColor);

    return `
      <div class="zen-top">
        <!-- Top row: Avatar + Name (Left Aligned) & Icons (Right Aligned) -->
        <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom: 24px;">
          <span class="zen-badge" style="padding-left:6px; margin:0;">
             ${avatarHtml}
             ${username}
          </span>
          <div style="display:flex; gap:16px; color:var(--text-secondary); align-items:center;">
            <!-- Support Icon -->
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path>
            </svg>
            <!-- Bell / Notification Icon -->
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
            </svg>
          </div>
        </div>

        <!-- The Bank Card -->
        <div style="background: linear-gradient(135deg, #a4a29e, #85827c); border-radius: 20px; padding: 24px; position: relative; color: #1c1c1e; box-shadow: 0 10px 30px rgba(0,0,0,0.1); height: 220px; display: flex; flex-direction: column; justify-content: space-between;">
          <div style="display: flex; justify-content: space-between; align-items: flex-start;">
            <div>
              <div style="font-size: 14px; font-weight: 600; opacity: 0.7; margin-bottom: 4px;">Available balance</div>
              <div style="font-size: 40px; font-weight: 800; letter-spacing: -0.03em; display: flex; align-items: baseline;">
                <span style="font-size:28px; margin-right:4px;">$</span><span>${intPart}</span><span style="font-size:28px;">${centsPart}</span>
              </div>
            </div>
            <!-- Contactless Icon -->
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="opacity:0.8;">
              <path d="M8.5 4c2.5 0 4.5 2 4.5 4.5S11 13 8.5 13"></path>
              <path d="M12.5 2c3.5 0 6.5 3 6.5 6.5S16 15 12.5 15"></path>
              <path d="M16.5 0C21.2 0 25 3.8 25 8.5S21.2 17 16.5 17"></path>
            </svg>
          </div>
          
          <div style="display: flex; justify-content: space-between; align-items: flex-end;">
            <div style="font-size: 14px; font-weight: 700; letter-spacing: 0.1em; text-transform: uppercase; opacity:0.8;">${username}</div>
            <div style="font-size: 28px; font-weight: 800; font-style: italic; line-height:1; letter-spacing:-0.05em;">VISA <span style="font-size:10px; font-weight: 600; font-style: normal; display:block; text-align:right; letter-spacing:0; margin-top:-2px;">Platinum</span></div>
          </div>
        </div>

        <!-- Quick Stats List -->
        <div style="display: flex; justify-content: space-between; margin-top: 32px; padding: 0 8px;">
          <div style="text-align: left;">
            <div style="font-size:13px; color:var(--text-secondary); font-weight:600;">Investments</div>
            <div style="font-size:16px; color:#000; font-weight:700; margin-top:4px;">$70,850</div>
          </div>
          <div style="text-align: left;">
            <div style="font-size:13px; color:var(--text-secondary); font-weight:600;">Shared</div>
            <div style="font-size:16px; color:#000; font-weight:700; margin-top:4px;">$1,200.50</div>
          </div>
          <div style="text-align: left;">
            <div style="font-size:13px; color:var(--text-secondary); font-weight:600;">Loans</div>
            <div style="font-size:16px; color:#000; font-weight:700; margin-top:4px;">$0.00</div>
          </div>
        </div>
      </div>`;
  }

  function renderActions() {
    return `
      <div class="zen-middle">
        <button class="zen-act" data-act="send">
          <img src="assets/icons/down-right.svg" style="transform: scaleY(-1);" /> Send
        </button>
        <button class="zen-act" data-act="receive">
          <img src="assets/icons/down-right.svg" /> Receive
        </button>
        <button class="zen-act" data-act="swap">
          <img src="assets/icons/shuffle.svg" /> Swap
        </button>
      </div>`;
  }

  function renderTokens() {
    const rows = S.state.tokens.map(t => {
      const f = S.tokenFiat(t);
      const up = t.change24 >= 0;
      return `
        <div class="list-row tap zen-row" data-token="${t.id}">
          ${UI.tokenIcon(t)}
          <div class="row-main">
            <div class="sym" style="font-size: 16px; font-weight: 650; letter-spacing: -0.01em; margin-bottom: 2px;">${t.name}</div>
            <div class="sub" style="font-size: 13px; display: flex; gap: 6px;">
               <span>$${UI.fmtNum(t.price, 3)}</span>
               <span class="delta ${up ? "delta-up" : "delta-down"}">${UI.fmtPct(t.change24)}</span>
            </div>
          </div>
          <div class="row-trail" style="display: flex; flex-direction: column; align-items: flex-end; gap: 2px; flex-shrink: 0;">
            <div class="sym t-num" style="font-size: 15px; font-weight: 650;">${UI.fmtTokenAmt(t.balance)} ${t.symbol.toUpperCase()}</div>
            <div class="sub t-num" style="font-size: 13px;">${UI.fmtUSD(f)}</div>
          </div>
        </div>`;
    }).join("");
    return `
      <div class="zen-bottom">
        <div class="zen-bottom-head">
          <span>Assets</span>
          <a href="#">View all ›</a>
        </div>
        <div class="zen-filter">
          <span class="zf-pill active">All</span>
          <span class="zf-pill">Crypto</span>
          <span class="zf-pill">Fiat</span>
        </div>
        <div class="list" style="background:transparent;box-shadow:none;">${rows}</div>
      </div>`;
  }

  function render() {
    if (S.state.loading) {
      return `<div class="screen flex" style="align-items:center;justify-content:center;height:100vh;background:#fff;"><div class="spinner lg"></div></div>`;
    }
    return `
      <div class="zen-screen">
        ${renderHero()}
        ${renderActions()}
        ${renderTokens()}
      </div>`;
  }

  function mount(root) {
    // Анимация счётчика баланса
    const balEl = root.querySelector("#dashBalance");
    if (balEl) UI.countUp(balEl, S.totalFiat(), { dur: 900, fmt: v => UI.fmtUSD(v, { max: 2 }) });

    // Тап по hero-карточке → История (push)
    root.querySelector(".dash-hero")?.addEventListener("click", () => {
      UI.push({
        title: "",
        render: () => Screens.activity.render(),
        onMount: (view) => Screens.activity.mount(view)
      });
    });

    // Действия
    root.querySelectorAll("[data-act]").forEach(el => {
      el.addEventListener("click", () => {
        const a = el.getAttribute("data-act");
        if (a === "send") window.NovaScreens.send.open();
        else if (a === "receive") window.NovaScreens.receive.open();
        else if (a === "swap") window.NovaScreens.swap.open();
      });
    });

    // Тап по токену → детали токена (push)
    root.querySelectorAll("[data-token]").forEach(el => {
      el.addEventListener("click", () => {
        const id = el.getAttribute("data-token");
        Screens.token.open(id);
      });
    });
  }

  return { render, mount };
})();

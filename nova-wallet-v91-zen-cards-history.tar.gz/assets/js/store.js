/* ==========================================================================
   Nova Wallet — Store (простое управление состоянием)
   ========================================================================== */

window.NovaStore = (function () {
  "use strict";

  const data = window.NovaData;

  // Telegram initData for auth
  const tg = window.Telegram && window.Telegram.WebApp;
  const initData = tg ? tg.initData : '';

  function authHeaders() {
    return {
      'Content-Type': 'application/json',
      'X-Telegram-Init-Data': initData
    };
  }

  // State
  const state = {
    screen: "dashboard",
    tokens: [],
    nfts: data.NFTS.map(n => ({ ...n })),
    pools: [],
    txs: [],
    user: null,
    wallet: { ...data.WALLET },
    toast: null,
    loading: true
  };

  const subs = [];
  function subscribe(fn) { subs.push(fn); }
  function notify() { subs.forEach(fn => { try { fn(state); } catch (e) { console.error(e); } }); }

  async function init() {
    const preloadImages = async () => {
      const icons = state.tokens.map(t => t.icon).filter(Boolean);
      await Promise.all(icons.map(src => new Promise(resolve => {
        const img = new Image();
        img.onload = resolve;
        img.onerror = resolve;
        img.src = src;
      })));
    };

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 300); // 300ms max for demo
      const res = await fetch('/api/wallet', { headers: authHeaders(), signal: controller.signal });
      clearTimeout(timeoutId);
      
      if (!res.ok) throw new Error('Failed to fetch from backend');
      const backendData = await res.json();
      state.tokens = backendData.balances || [];
      state.txs = backendData.transactions || [];
      state.user = backendData.user || null;
      if (backendData.pools && backendData.pools.length) {
        state.pools = backendData.pools;
      } else {
        state.pools = data.POOLS.map(p => ({ ...p }));
      }
      if (backendData.nfts && backendData.nfts.length) {
        state.nfts = backendData.nfts;
      }
      if (backendData.user) {
        state.wallet = {
          name: backendData.user.username || 'My Wallet',
          ens: backendData.user.ens || 'nova.eth',
          address: backendData.user.walletAddress || data.WALLET.address,
          avatarInitial: (backendData.user.username || 'N')[0].toUpperCase()
        };
      }
      await preloadImages();
      state.loading = false;
      notify();
    } catch (e) {
      console.error('API Error:', e);
      // Fallback to data.js
      state.tokens = data.TOKENS.map(t => ({ ...t }));
      state.txs = data.TXS.map(t => ({ ...t }));
      state.pools = data.POOLS.map(p => ({ ...p }));
      await preloadImages();
      state.loading = false;
      notify();
    }
  }

  // Refresh data from backend (call after send/swap/stake)
  async function refresh() {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 300);
      const res = await fetch('/api/wallet', { headers: authHeaders(), signal: controller.signal });
      clearTimeout(timeoutId);
      if (!res.ok) return;
      const backendData = await res.json();
      state.tokens = backendData.balances || [];
      state.txs = backendData.transactions || [];
      state.user = backendData.user || null;
      if (backendData.pools && backendData.pools.length) {
        state.pools = backendData.pools;
      }
      notify();
    } catch (e) {
      console.error('Refresh error:', e);
    }
  }

  // Auto-refresh removed per user request

  function setScreen(name) {
    state.screen = name;
    notify();
  }

  // --- API-backed operations ---
  async function apiSend(tokenId, amount, toAddress) {
    const res = await fetch('/api/send', {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify({ tokenId, amount, toAddress })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Send failed');
    await refresh();
    return data;
  }

  async function apiSwap(fromTokenId, toTokenId, amount, slippage) {
    const res = await fetch('/api/swap', {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify({ fromTokenId, toTokenId, amount, slippage })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Swap failed');
    await refresh();
    return data;
  }

  async function apiStake(poolId, amount) {
    const res = await fetch('/api/stake', {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify({ poolId, amount })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Stake failed');
    await refresh();
    return data;
  }

  // Legacy local-only operations (kept for fallback/offline)
  function applySend(tokenId, amount, fee) {
    const t = state.tokens.find(x => x.id === tokenId);
    if (!t) return;
    t.balance = Math.max(0, +(t.balance - amount).toFixed(6));
    notify();
  }

  function applySwap(payId, payAmt, recvId, recvAmt) {
    const pay = state.tokens.find(x => x.id === payId);
    const recv = state.tokens.find(x => x.id === recvId);
    if (pay) pay.balance = Math.max(0, +(pay.balance - payAmt).toFixed(6));
    if (recv) recv.balance = +(recv.balance + recvAmt).toFixed(6);
    notify();
  }

  function applyStake(poolId, amount) {
    const p = state.pools.find(x => x.id === poolId);
    const t = state.tokens.find(x => x.symbol === p.asset);
    if (t) t.balance = Math.max(0, +(t.balance - amount).toFixed(6));
    p.staked = +(p.staked + amount).toFixed(6);
    p.rewards = +(p.staked * p.apy / 100 / 12).toFixed(4);
    notify();
  }

  function addTx(tx) {
    state.txs.unshift({ id: Date.now(), status: "success", ...tx });
    notify();
  }

  // Derived
  function totalFiat() { return state.tokens.reduce((s, t) => s + t.balance * t.price, 0); }
  function tokenFiat(t) { return t.balance * t.price; }
  function findToken(id) { return state.tokens.find(t => t.id === id); }
  function stakedFiat() {
    return state.pools.reduce((s, p) => {
      const t = state.tokens.find(x => x.symbol === p.asset);
      const price = t ? t.price : 0;
      return s + p.staked * price;
    }, 0);
  }
  function totalRewardsFiat() {
    return state.pools.reduce((s, p) => {
      const t = state.tokens.find(x => x.symbol === p.asset);
      const price = t ? t.price : 0;
      return s + p.rewards * price;
    }, 0);
  }

  return {
    state, subscribe, setScreen, notify,
    applySend, applySwap, applyStake, addTx,
    totalFiat, tokenFiat, findToken, stakedFiat, totalRewardsFiat,
    init, refresh, apiSend, apiSwap, apiStake, authHeaders
  };
})();

import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function GET() {
  try {
    // In a real app, you'd get the user from auth token. Here we use our demo_user.
    const user = await prisma.user.findUnique({
      where: { telegramId: 'demo_user' },
      include: {
        balances: {
          include: {
            token: true
          }
        },
        transactions: {
          orderBy: { createdAt: 'desc' },
          take: 20
        }
      }
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Format the response to match what the frontend expects
    const balances = user.balances.map(b => ({
      id: b.token.id,
      symbol: b.token.symbol,
      name: b.token.name,
      balance: b.balance,
      price: b.token.priceUsd,
      change24h: b.token.change24,
      icon: b.token.icon,
      color: b.token.color
    }));

    const totalBalance = balances.reduce((sum, b) => sum + (b.balance * b.price), 0);

    return NextResponse.json({
      user: {
        id: user.id,
        username: user.username,
        totalBalance
      },
      balances,
      transactions: user.transactions
    });
  } catch (error) {
    console.error('Wallet API Error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function fetchBinancePrice(symbol: string): Promise<number> {
  try {
    const res = await fetch(`https://api.binance.com/api/v3/ticker/price?symbol=${symbol}USDT`);
    if (!res.ok) return 0;
    const data = await res.json();
    return parseFloat(data.price);
  } catch (e) {
    console.error(`Error fetching price for ${symbol}:`, e);
    return 0;
  }
}

async function main() {
  console.log('Fetching live prices from Binance...');
  
  const btcPrice = await fetchBinancePrice('BTC');
  const ethPrice = await fetchBinancePrice('ETH');
  const solPrice = await fetchBinancePrice('SOL');
  const tonPrice = await fetchBinancePrice('TON'); // Or skip if not on Binance USDT pair, but TON is often available or we use a fallback
  const maticPrice = await fetchBinancePrice('POL'); // Polygon migrated to POL

  console.log('Seeding tokens with real prices...');
  
  const tokens = [
    { id: 'btc', symbol: 'BTC', name: 'Bitcoin', priceUsd: btcPrice || 64000, change24: 2.5, icon: 'BTC.svg', color: 'rgba(247, 147, 26, 0.2)' },
    { id: 'eth', symbol: 'ETH', name: 'Ethereum', priceUsd: ethPrice || 3500, change24: 1.2, icon: 'eth.svg', color: 'rgba(98, 126, 234, 0.2)' },
    { id: 'sol', symbol: 'SOL', name: 'Solana', priceUsd: solPrice || 140, change24: -0.5, icon: 'SOL.svg', color: 'rgba(20, 241, 149, 0.2)' },
    { id: 'ton', symbol: 'TON', name: 'Toncoin', priceUsd: tonPrice || 7.5, change24: 5.4, icon: 'TON.svg', color: 'rgba(0, 152, 234, 0.2)' },
    { id: 'usdt', symbol: 'USDT', name: 'Tether', priceUsd: 1.0, change24: 0.0, icon: 'USDT.svg', color: 'rgba(38, 161, 123, 0.2)' },
    { id: 'usdc', symbol: 'USDC', name: 'USD Coin', priceUsd: 1.0, change24: 0.0, icon: 'USDC.svg', color: 'rgba(39, 117, 202, 0.2)' },
    { id: 'pol', symbol: 'POL', name: 'Polygon', priceUsd: maticPrice || 0.4, change24: 1.1, icon: 'POL.svg', color: 'rgba(130, 71, 229, 0.2)' },
  ];

  for (const t of tokens) {
    await prisma.token.upsert({
      where: { symbol: t.symbol },
      update: { priceUsd: t.priceUsd, change24: t.change24, icon: t.icon, color: t.color },
      create: t,
    });
  }

  console.log('Creating mock user...');
  const user = await prisma.user.upsert({
    where: { telegramId: 'demo_user' },
    update: {},
    create: {
      telegramId: 'demo_user',
      username: 'DemoTrader',
      isAdmin: true,
      balances: {
        create: [
          { tokenId: 'btc', balance: 0.15 },
          { tokenId: 'eth', balance: 2.4 },
          { tokenId: 'usdt', balance: 1543.20 },
          { tokenId: 'ton', balance: 150 },
        ]
      }
    }
  });

  console.log('Seeding finished successfully!');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

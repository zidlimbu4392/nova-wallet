﻿/* ==========================================================================
   Nova Wallet — Swap screen
   ========================================================================== */

window.NovaScreens = window.NovaScreens || {};

window.NovaScreens.swap = (function () {
  "use strict";
  const UI = window.NovaUI, S = window.NovaStore, D = window.NovaData;

  // Локальное состояние экрана
  let pay = "eth", recv = "usdt", payAmt = "";
  let slippage = 0.5;

  function tk(id) { return S.findToken(id); }
  function price(id) { const t = tk(id); return t ? t.price : 0; }
  function rate() { return price(pay) / (price(recv) || 1); }
  function recvAmt() {
    const a = parseFloat(payAmt) || 0;
    if (!a) return 0;
    return a * rate() * (1 - slippage / 100);
  }

  function tokenPicker(onPick, excludeId) {
    const items = S.state.tokens
      .filter(t => t.id !== excludeId)
      .map(t => `
        <div class="tp-row" data-pick="${t.id}">
          ${UI.tokenIcon(t, "sm")}
          <div>
            <div style="font-weight:650;font-size:15px">${t.symbol}</div>
            <div class="t-footnote">${t.name}</div>
          </div>
          <div class="tp-amt t-num">${UI.fmtTokenAmt(t.balance)}</div>
        </div>`).join("");
    return `<div class="token-picker">${items}</div>`;
  }

  function openPicker(which) {
    const exclude = which === "pay" ? recv : pay;
    UI.sheet({
      title: "Select token",
      body: tokenPicker(null, exclude),
      onMount: (el) => {
        el.querySelectorAll("[data-pick]").forEach(r => {
          r.addEventListener("click", () => {
            const id = r.getAttribute("data-pick");
            if (which === "pay") pay = id; else recv = id;
            if (pay === recv) {
              if (which === "pay") recv = (S.state.tokens.find(t=>t.id!==pay)||{}).id;
              else pay = (S.state.tokens.find(t=>t.id!==recv)||{}).id;
            }
            UI.closeSheet();
            if (rerenderFn) setTimeout(rerenderFn, 340);
          });
        });
      }
    });
  }

  function renderCard(which) {
    const tid = which === "pay" ? pay : recv;
    const t = tk(tid);
    if (!t) return "";
    const bal = t.balance;
    const isPay = which === "pay";
    const amtVal = isPay ? (payAmt || "") : UI.fmtTokenAmt(recvAmt());
    const fiat = (isPay ? (parseFloat(payAmt)||0) : recvAmt()) * t.price;
    return `
      <div class="swap-section">
        <div class="ss-top">
          <span class="ss-label">${isPay ? "You send" : "You get"}</span>
          ${isPay ? `<span class="ss-bal t-num">${UI.fmtTokenAmt(bal)} <b data-max>MAX</b></span>` : ""}
        </div>
        <div class="ss-main">
          <button class="ss-token" data-pick-btn="${which}">
            ${UI.tokenIcon(t, "")}
            <span class="ss-token-name">${t.symbol}</span>
            <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="color:var(--text-secondary);flex-shrink:0"><path d="M6 9l6 6 6-6"/></svg>
          </button>
          <input class="ss-amt t-num" id="swapAmt-${which}"
                 inputmode="decimal" placeholder="0" value="${amtVal}"
                 ${isPay ? "" : "readonly"} />
        </div>
        <div class="ss-fiat t-num">≈ ${UI.fmtUSD(fiat)}</div>
      </div>`;
  }

  function render() {
    const t = tk(pay);
    const r = tk(recv);
    const r1 = rate();
    return `
      <div class="swap-wrap">
        ${renderCard("pay")}
        <div class="swap-divider-line">
          <div class="sdl-line"></div>
          <button class="swap-switch" data-switch aria-label="Swap">${UI.icon("shuffle")}</button>
          <div class="sdl-line"></div>
        </div>
        ${renderCard("recv")}
        <div class="swap-bottom-info">
          <div class="swap-meta">
            <div class="m-row"><span class="muted">Rate</span><span class="m-val t-num">1 ${t?t.symbol:""} ≈ ${UI.fmtNum(r1, 4)} ${r?r.symbol:""}</span></div>
            <div class="m-row"><span class="muted">Min received</span><span class="m-val t-num">${UI.fmtTokenAmt(recvAmt())} ${r?r.symbol:""}</span></div>
            <div class="m-row"><span class="muted">Slippage</span>
              <span class="swap-slip">
                ${[0.1,0.5,1].map(p=>`<button class="slip-pill ${p===slippage?'active':''}" data-slip="${p}">${p}%</button>`).join("")}
              </span>
            </div>
            <div class="m-row"><span class="muted">Network fee</span><span class="m-val t-num">≈ ${UI.fmtUSD(0.42)}</span></div>
          </div>
          <button class="btn btn-primary btn-block btn-pill swap-continue" data-swap-go ${(!payAmt || recvAmt()<=0) ? "disabled" : ""}>
            Continue
          </button>
        </div>
      </div>`;
  }

  function mount(root) {
    function rerender() {
      const body = root.querySelector(".push-body") || root;
      body.innerHTML = render();
      bindAll();
    }

    function bindAll() {
      const el = root;

      el.querySelector("[data-switch]")?.addEventListener("click", () => {
        const tmp = pay; pay = recv; recv = tmp;
        payAmt = "";
        rerender();
      });

      el.querySelectorAll("[data-pick-btn]").forEach(b => {
        b.addEventListener("click", () => openPicker(b.getAttribute("data-pick-btn")));
      });

      const amtInput = el.querySelector("#swapAmt-pay");
      if (amtInput) {
        amtInput.addEventListener("input", (e) => {
          payAmt = e.target.value.replace(/[^0-9.]/g, "");
          if (payAmt.split(".").length > 2) payAmt = payAmt.slice(0, -1);
          e.target.value = payAmt;
          const recvInput = el.querySelector("#swapAmt-recv");
          if (recvInput) recvInput.value = UI.fmtTokenAmt(recvAmt());
          updateFiat(el); updateBtn(el);
        });
      }

      el.querySelector("[data-max]")?.addEventListener("click", () => {
        const t = tk(pay);
        if (!t) return;
        payAmt = String(t.balance);
        if (amtInput) amtInput.value = payAmt;
        const recvInput = el.querySelector("#swapAmt-recv");
        if (recvInput) recvInput.value = UI.fmtTokenAmt(recvAmt());
        updateFiat(el); updateBtn(el);
      });

      el.querySelectorAll("[data-slip]").forEach(b => {
        b.addEventListener("click", () => {
          slippage = parseFloat(b.getAttribute("data-slip"));
          const recvInput = el.querySelector("#swapAmt-recv");
          if (recvInput) recvInput.value = UI.fmtTokenAmt(recvAmt());
          updateFiat(el);
          el.querySelectorAll("[data-slip]").forEach(x => x.classList.toggle("active", x === b));
        });
      });

      el.querySelector("[data-swap-go]")?.addEventListener("click", doSwap);
    }

    // Локальный rerender для openPicker
    rerenderFn = rerender;

    bindAll();
  }

  let rerenderFn = null;

  function updateFiat(root) {
    const t = tk(pay), r = tk(recv);
    const fiats = root.querySelectorAll(".ss-fiat");
    if (fiats[0] && t) fiats[0].textContent = "≈ " + UI.fmtUSD((parseFloat(payAmt)||0) * t.price);
    if (fiats[1] && r) fiats[1].textContent = "≈ " + UI.fmtUSD(recvAmt() * r.price);
  }

  function updateBtn(root) {
    const btn = root.querySelector("[data-swap-go]");
    if (btn) btn.disabled = (!payAmt || recvAmt() <= 0);
  }

  function doSwap() {
    const a = parseFloat(payAmt) || 0;
    if (a <= 0) return;
    const t = tk(pay), r = tk(recv);
    const recvA = recvAmt();

    // Проверка баланса
    if (t && a > t.balance) {
      UI.toast("Insufficient " + t.symbol, "error");
      return;
    }

    // Шторка с подтверждением -> загрузка -> успех
    const body = document.createElement("div");
    body.innerHTML = `
      <div class="send-review">
        <div class="r-row"><span class="k">Send</span><span class="v t-num">${UI.fmtTokenAmt(a)} ${t?t.symbol:""}</span></div>
        <div class="r-row"><span class="k">Get</span><span class="v t-num">${UI.fmtTokenAmt(recvA)} ${r?r.symbol:""}</span></div>
        <div class="r-row"><span class="k">Rate</span><span class="v t-num">1 ${t?t.symbol:""} ≈ ${UI.fmtNum(rate(),4)} ${r?r.symbol:""}</span></div>
        <div class="r-row"><span class="k">Slippage</span><span class="v">${slippage}%</span></div>
        <div class="r-row"><span class="k">Network fee</span><span class="v t-num">${UI.fmtUSD(0.42)}</span></div>
      </div>`;

    const footer = document.createElement("div");
    footer.innerHTML = `<button class="btn btn-primary btn-block btn-pill" data-confirm>Confirm swap</button>`;

    const sh = UI.sheet({ title: "Review swap", body, footer });
    sh.el.querySelector("[data-confirm]").addEventListener("click", () => {
      // состояние загрузки
      footer.innerHTML = `<button class="btn btn-primary btn-block" disabled><span class="spinner on-accent"></span> Processing…</button>`;
      setTimeout(() => {
        // применяем
        S.applySwap(pay, a, recv, recvA);
        S.addTx({
          type: "swap", token: `${t?t.symbol:""}→${r?r.symbol:""}`,
          amount: a, fiat: a * (t?t.price:0),
          time: "Сегодня, " + UI.fmtTimeHM(),
          rate: `1 ${t?t.symbol:""} = ${UI.fmtNum(rate(),4)} ${r?r.symbol:""}`
        });
        showSwapSuccess(sh.el, a, t, recvA, r);
      }, 1400);
    });
  }

  function showSwapSuccess(sheetEl, a, t, recvA, r) {
    sheetEl.querySelector(".sheet-body").innerHTML = `
      <div class="sheet-state">
        <div class="success-ring">${UI.icon("check")}</div>
        <div class="ss-title">Swap complete</div>
        <div class="ss-sub">${UI.fmtTokenAmt(a)} ${t?t.symbol:""} → ${UI.fmtTokenAmt(recvA)} ${r?r.symbol:""}</div>
      </div>`;
    sheetEl.querySelector(".sheet-footer").innerHTML = `<button class="btn btn-secondary btn-block" data-close>Done</button>`;
    UI.toast("Swap complete", "success");
    // сбросим сумму на экране
    payAmt = "";
  }

  /* Push-открытие (как Send/Receive) */
  function open() {
    UI.push({
      title: "",
      render: () => render(),
      onMount: (view) => mount(view)
    });
  }

  function setPay(id) { pay = id; }
  function setRecv(id) { recv = id; }

  return { render, mount, open, setPay, setRecv };
})();

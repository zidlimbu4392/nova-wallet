import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { authenticateRequest } from '@/lib/auth';

const prisma = new PrismaClient();

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  try {
    // Authenticate (falls back to demo_user in dev mode)
    const auth = await authenticateRequest(request);
    if (!auth) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const user = await prisma.user.findUnique({
      where: { id: auth.userId },
      include: {
        balances: {
          include: { token: true }
        },
        transactions: {
          orderBy: { createdAt: 'desc' },
          take: 20
        }
      }
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Map balances — matching data.js format exactly
    const balances = user.balances.map(b => ({
      id: b.token.id,
      symbol: b.token.symbol,
      name: b.token.name,
      balance: b.balance,
      price: b.token.priceUsd,
      change24: b.token.change24,
      icon: b.token.icon,
      color: b.token.color,
      glyph: b.token.glyph,
      chain: b.token.chain
    }));

    const totalBalance = balances.reduce((sum, b) => sum + (b.balance * b.price), 0);

    // Build tokenId → token map for transactions
    const allTokens = await prisma.token.findMany();
    const tokenMap: Record<string, any> = {};
    allTokens.forEach(t => { tokenMap[t.id] = t; });

    // Map transactions — matching data.js TXS format EXACTLY
    const now = new Date();
    const formattedTxs = user.transactions.map(tx => {
      const tok = tx.tokenId ? tokenMap[tx.tokenId] : null;
      const symbol = tok?.symbol || '';

      const txDate = new Date(tx.createdAt);
      const isToday = txDate.toDateString() === now.toDateString();
      const yesterday = new Date(now);
      yesterday.setDate(yesterday.getDate() - 1);
      const isYesterday = txDate.toDateString() === yesterday.toDateString();
      
      const timeHM = txDate.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
      let dayPart: string;
      if (isToday) dayPart = 'Today';
      else if (isYesterday) dayPart = 'Yesterday';
      else dayPart = txDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });

      const timeStr = `${dayPart}, ${timeHM}`;

      let tokenStr = symbol;
      if (tx.type === 'swap' && tx.note) {
        tokenStr = tx.note;
      }

      return {
        id: tx.id,
        type: tx.type,
        token: tokenStr,
        amount: tx.amount,
        fiat: tx.fiatValue || 0,
        time: timeStr,
        status: tx.status,
        from: tx.fromAddr || undefined,
        to: tx.toAddress || undefined,
        hash: tx.hash || undefined,
        fee: tx.fee || undefined,
        rate: tx.type === 'swap' && tx.note ? `1 ${symbol} = ${(tok?.priceUsd || 0).toLocaleString()} USDT` : undefined,
        note: tx.note || undefined
      };
    });

    // Get staking pools
    const pools = await prisma.stakingPool.findMany();

    return NextResponse.json({
      user: {
        id: user.id,
        username: user.username,
        totalBalance,
        isAdmin: user.isAdmin
      },
      balances,
      transactions: formattedTxs,
      pools: pools.map(p => ({
        id: p.id,
        asset: p.asset,
        name: p.name,
        apy: p.apy,
        tvl: p.tvl,
        staked: p.staked,
        rewards: p.rewards,
        color: p.color,
        glyph: p.glyph
      }))
    });
  } catch (error) {
    console.error('Wallet API Error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

/* ==========================================================================
   Nova Wallet — App (роутер, навигация, инициализация)
   ========================================================================== */

window.NovaApp = (function () {
  "use strict";
  const UI = window.NovaUI, S = window.NovaStore;
  const Screens = window.NovaScreens;

  // Конфиг нижней навигации (3 вкладки)
  const TABS = [
    { id: "dashboard", label: "Wallet",  icon: "assets/icons/wallet.svg"   },
    { id: "nft",       label: "NFT",     icon: "assets/icons/gem.svg"      },
    { id: "staking",   label: "Earn",    icon: "assets/icons/earnings.svg" }
  ];

  const appEl = () => document.getElementById("app");
  const tabEl = () => document.getElementById("tabbar");

  let pendingRerender = false;
  let isOverlayOpen = () =>
    document.getElementById("sheetHost").classList.contains("open") ||
    document.getElementById("pushHost").classList.contains("open");

  /* ---------- Рендер нижней навигации ---------- */
  function renderTabbar() {
    const cur = S.state.screen;
    const te = tabEl();
    
    // Toggle visibility based on loading state
    if (S.state.loading) {
      te.classList.remove("visible");
    } else {
      te.classList.add("visible");
    }
    
    // Initial render if empty
    if (!te.querySelector(".tab-indicator")) {
      let tabsHtml = TABS.map(t => `
        <button class="tab ${t.id === cur ? "active" : ""}" data-tab="${t.id}" aria-label="${t.label}">
          <img class="tab-ico" src="${t.icon}" alt="" />
          <span class="tab-label">${t.label}</span>
        </button>`).join("");
        
      te.innerHTML = `<div class="tab-indicator" id="tabIndicator"></div>` + tabsHtml;
      
      te.querySelectorAll("[data-tab]").forEach(b => {
        b.addEventListener("click", () => S.setScreen(b.getAttribute("data-tab")));
      });
    } else {
      // Update active classes
      te.querySelectorAll("[data-tab]").forEach(b => {
        if (b.getAttribute("data-tab") === cur) {
          b.classList.add("active");
        } else {
          b.classList.remove("active");
        }
      });
    }
    
    requestAnimationFrame(() => {
      requestAnimationFrame(updateTabIndicator);
    });
  }

  function updateTabIndicator() {
    const active = tabEl().querySelector(".tab.active");
    const ind = document.getElementById("tabIndicator");
    if (active && ind) {
      ind.style.width = active.offsetWidth + "px";
      ind.style.transform = `translate3d(${active.offsetLeft}px, 0, 0)`;
    }
  }

  /* ---------- Рендер текущего экрана ---------- */
  function renderScreen() {
    const name = S.state.screen;
    const scr = Screens[name];
    const root = appEl();
    if (!scr) { root.innerHTML = "<div class='state'>Screen not found</div>"; return; }
    
    // Скрываем все экраны
    let allScreens = root.querySelectorAll(".screen-wrapper");
    allScreens.forEach(el => el.style.display = "none");

    // Ищем или создаем контейнер для текущего экрана
    let container = document.getElementById("screen-" + name);
    if (!container) {
      container = document.createElement("div");
      container.id = "screen-" + name;
      container.className = "screen-wrapper";
      container.style.display = "none";
      root.appendChild(container);
    }

    const needsRender = true; // Always update HTML to keep data fresh

    if (needsRender) {
      container.innerHTML = scr.render();
      if (scr.mount) {
        try { scr.mount(container); } catch (e) { console.error("mount error", name, e); }
      }
      if (!S.state.loading) {
        if (!container.dataset.loaded) {
          container.style.opacity = "0"; // hide initially
          container.dataset.loaded = "waiting";
          const imgs = Array.from(container.querySelectorAll('img'));
          const promises = imgs.map(img => {
            if (img.complete) return Promise.resolve();
            return new Promise(resolve => {
              img.onload = resolve;
              img.onerror = resolve;
            });
          });
          
          Promise.all(promises).then(() => {
            container.style.opacity = ""; 
            container.classList.add("fade-in-slow");
            container.dataset.loaded = "true";
          });
        }
      }
    }

    // Show without animation to prevent blinking
    container.style.display = "block";
    if (S.state.loading || container.dataset.loaded === "true") {
        container.style.opacity = "1";
    }
    container.style.transform = "translateY(0)";
    
    // Сброс скролла окна
    window.scrollTo(0, 0);
  }

  function rerender() {
    renderTabbar();
    // Принудительно рендерим экран (удаляем флаг загруженности)
    const name = S.state.screen;
    const container = document.getElementById("screen-" + name);
    if (container) container.dataset.loaded = "";
    renderScreen();
  }

  /* ---------- Подписка на изменения состояния ---------- */
  S.subscribe(() => {
    if (isOverlayOpen()) {
      pendingRerender = true;
    } else {
      rerender();
    }
  });

  document.addEventListener("nova:sheetclosed", checkRerender);
  document.addEventListener("nova:pushclosed", checkRerender);

  function checkRerender() {
    if (pendingRerender && !isOverlayOpen()) {
      pendingRerender = false;
      rerender();
    }
  }

  /* ---------- Статус-бар: часы ---------- */
  function updateClock() {
    const el = document.getElementById("statusTime");
    if (el) el.textContent = UI.fmtTimeHM();
  }

  /* ---------- Запуск ---------- */
  function init() {
    initTelegram();
    S.init(); // Fetch data from backend
    renderTabbar();
    renderScreen();
    updateClock();
    setInterval(updateClock, 1000 * 20);

    // Предзагрузка NFT чтобы они грузились мгновенно
    if (S.state.nfts) {
      S.state.nfts.forEach(n => {
        if (n.img) {
          const img = new Image();
          img.src = n.img;
        }
      });
    }
  }

  /* ---------- Telegram Mini App ---------- */
  function initTelegram() {
    const tg = window.Telegram && window.Telegram.WebApp;
    if (!tg) return;
    try {
      tg.ready();
      tg.expand();
      if (tg.setHeaderColor) tg.setHeaderColor("#ffffff");
      if (tg.setBackgroundColor) tg.setBackgroundColor("#ffffff");
      if (tg.enableClosingConfirmation) tg.enableClosingConfirmation();
    } catch (e) { console.warn("TG init", e); }
    document.body.classList.add("tg");
    // safe area снизу — чтобы плавающий таббар не прилипал к краю ТГ
    const sa = tg.safeAreaInset;
    if (sa && sa.bottom) {
      document.documentElement.style.setProperty("--tg-safe-bottom", sa.bottom + "px");
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  return { rerender, TABS };
})();

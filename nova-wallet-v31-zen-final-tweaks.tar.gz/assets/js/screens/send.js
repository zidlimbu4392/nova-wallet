/* ==========================================================================
   Nova Wallet — Send (full-screen push)
   ========================================================================== */

window.NovaScreens = window.NovaScreens || {};

window.NovaScreens.send = (function () {
  "use strict";
  const UI = window.NovaUI, S = window.NovaStore, D = window.NovaData;

  let tokenId = "eth", amount = "", to = "";

  function open(id) {
    if (id) tokenId = id;
    const t = S.findToken(tokenId) || S.state.tokens[0];
    tokenId = t.id; amount = ""; to = "";

    UI.push({
      title: "Send",
      render: () => `<div class="push-form">${renderForm(t)}</div>`,
      onMount: (view, close) => bindForm(view, t, close)
    });
  }

  function renderForm(t) {
    return `
      <div class="send-token-bar" data-asset>
        ${UI.tokenIcon(t, "")}
        <span class="stb-name">${t.symbol}</span>
        <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="color:var(--text-secondary)"><path d="M6 9l6 6 6-6"/></svg>
        <span class="stb-bal t-num">${UI.fmtTokenAmt(t.balance)} ${t.symbol}</span>
      </div>

      <div class="send-amount-box">
        <input class="sa-input t-num" id="sendAmt" inputmode="decimal" placeholder="0" />
        <button class="sa-max" data-max>MAX</button>
        <div class="sa-fiat t-num" id="sendFiat">≈ $0</div>
      </div>

      <div>
        <div class="sa-label">Recipient address</div>
        <div class="send-field">
          <input id="sendTo" placeholder="0x… or ENS" autocomplete="off" spellcheck="false" />
          <button class="send-paste" data-paste>Paste</button>
        </div>
      </div>

      <div class="send-fee-row">
        <span class="muted">Network fee</span>
        <span class="t-num">≈ ${UI.fmtUSD(0.42)} · ~15 sec</span>
      </div>

      <div class="push-bottom">
        <button class="btn btn-primary btn-block btn-pill" data-continue disabled>Continue</button>
      </div>`;
  }

  function bindForm(view, t, close) {
    const input = view.querySelector("#sendAmt");
    const toInput = view.querySelector("#sendTo");
    const btn = view.querySelector("[data-continue]");
    const fiatEl = view.querySelector("#sendFiat");
    const bal = t.balance;

    function valid() {
      const a = parseFloat(amount) || 0;
      const okAddr = /^0x[a-fA-F0-9]{6,}$/i.test(to.trim()) || /\.eth$/i.test(to.trim());
      btn.disabled = !(a > 0 && a <= bal && okAddr);
    }
    function recalc() {
      const a = parseFloat(amount) || 0;
      fiatEl.textContent = "≈ " + UI.fmtUSD(a * t.price);
      valid();
    }

    input.addEventListener("input", (e) => {
      amount = e.target.value.replace(/[^0-9.]/g, "");
      if (amount.split(".").length > 2) amount = amount.slice(0, -1);
      e.target.value = amount; recalc();
    });
    toInput.addEventListener("input", (e) => { to = e.target.value.trim(); valid(); });

    view.querySelector("[data-max]").addEventListener("click", () => {
      amount = String(t.symbol === "ETH" ? Math.max(0, bal - 0.01) : bal);
      input.value = amount; recalc();
    });

    view.querySelector("[data-paste]").addEventListener("click", async () => {
      let text = "";
      try {
        if (navigator.clipboard && window.isSecureContext) text = await navigator.clipboard.readText();
      } catch (e) {}
      if (!text) { try { text = window.prompt("Paste address (0x… or .eth):", "") || ""; } catch (e) {} }
      text = (text || "").trim().slice(0, 64);
      if (text) { to = text; toInput.value = to; valid(); UI.toast("Address pasted", "success"); }
      else UI.toast("Enter address manually", "default");
    });

    view.querySelector("[data-asset]").addEventListener("click", openAssetPicker);
    btn.addEventListener("click", () => review(view, t, close));
  }

  function openAssetPicker() {
    const items = S.state.tokens.map(t => `
      <div class="tp-row" data-pick="${t.id}">
        ${UI.tokenIcon(t, "sm")}
        <div><div style="font-weight:650">${t.symbol}</div><div class="t-footnote">${t.name}</div></div>
        <div class="tp-amt t-num">${UI.fmtTokenAmt(t.balance)}</div>
      </div>`).join("");
    UI.sheet({
      title: "Select asset",
      body: `<div class="token-picker">${items}</div>`,
      onMount: (el) => {
        el.querySelectorAll("[data-pick]").forEach(r => r.addEventListener("click", () => {
          tokenId = r.getAttribute("data-pick");
          UI.closeSheet(); UI.closePush();
          setTimeout(open, 340);
        }));
      }
    });
  }

  function review(view, t, close) {
    const a = parseFloat(amount) || 0;
    if (a <= 0 || a > t.balance) { UI.toast("Insufficient funds", "error"); return; }
    const dest = to.trim();
    const body = view.querySelector(".push-body");
    body.innerHTML = `
      <div class="push-form">
        <div class="send-review-hero">
          ${UI.tokenIcon(t, "lg")}
          <div class="srh-amt t-num">${UI.fmtTokenAmt(a)} <span class="muted">${t.symbol}</span></div>
          <div class="srh-fiat t-num">${UI.fmtUSD(a * t.price)}</div>
        </div>
        <div class="send-review-info">
          <div class="ri-row"><span>From</span><span>${D.WALLET.ens}</span></div>
          <div class="ri-row"><span>To</span><span class="t-mono">${UI.shortAddr(dest,8,6)}</span></div>
          <div class="ri-row"><span>Fee</span><span class="t-num">${UI.fmtUSD(0.42)}</span></div>
          <div class="ri-row"><span>Total</span><span class="t-num">${UI.fmtUSD(a*t.price + 0.42)}</span></div>
        </div>
        <div class="push-bottom">
          <div style="display:flex;gap:12px">
            <button class="btn btn-secondary btn-pill" data-back-form style="flex:1">Back</button>
            <button class="btn btn-primary btn-pill" data-confirm style="flex:1">Send</button>
          </div>
        </div>
      </div>`;

    body.querySelector("[data-back-form]").addEventListener("click", () => {
      const t2 = S.findToken(tokenId);
      body.innerHTML = `<div class="push-form">${renderForm(t2)}</div>`;
      bindForm(view, t2, close);
    });
    body.querySelector("[data-confirm]").addEventListener("click", () => {
      body.innerHTML = `<div class="push-form"><div style="text-align:center;padding-top:80px"><div class="spinner lg"></div><div style="margin-top:16px;color:var(--text-secondary)">Sending…</div></div></div>`;
      S.apiSend(tokenId, a, dest).then((result) => {
        body.innerHTML = `
          <div class="push-form">
            <div style="text-align:center;padding-top:80px">
              <div class="success-ring">${UI.icon("check")}</div>
              <div style="font-size:20px;font-weight:700;margin-top:20px">Sent</div>
              <div style="font-size:30px;font-weight:800;margin-top:12px">${UI.fmtTokenAmt(a)} <span style="color:var(--text-secondary)">${t.symbol}</span></div>
              <div style="color:var(--text-secondary);margin-top:6px">→ ${UI.shortAddr(dest,8,6)}</div>
            </div>
            <div class="push-bottom">
              <button class="btn btn-secondary btn-block btn-pill" data-done>Done</button>
            </div>
          </div>`;
        body.querySelector("[data-done]").addEventListener("click", close);
        UI.toast("Transfer sent", "success");
      }).catch((err) => {
        body.innerHTML = `
          <div class="push-form">
            <div style="text-align:center;padding-top:80px">
              <div class="error-ring">${UI.icon("alert")}</div>
              <div style="font-size:20px;font-weight:700;margin-top:20px;color:var(--danger)">Failed</div>
              <div style="color:var(--text-secondary);margin-top:8px">${err.message}</div>
            </div>
            <div class="push-bottom">
              <button class="btn btn-secondary btn-block btn-pill" data-done>Close</button>
            </div>
          </div>`;
        body.querySelector("[data-done]").addEventListener("click", close);
        UI.toast(err.message, "error");
      });
    });
  }

  return { open };
})();

/* ==========================================================================
   Nova Wallet — Receive (full-screen push)
   ========================================================================== */

window.NovaScreens = window.NovaScreens || {};

window.NovaScreens.receive = (function () {
  "use strict";
  const UI = window.NovaUI, S = window.NovaStore, D = window.NovaData;
  let net = "eth";

  function open() {
    // Use wallet from backend (state) or fallback to data.js
    const w = S.state.wallet || D.WALLET;
    const networks = D.NETWORKS;
    const sel = networks.find(n => n.id === net) || networks[0];

    UI.push({
      title: "Receive",
      render: () => `
        <div class="push-form">
          <div class="recv-net">
            ${networks.map(n => `<button class="n-pill ${n.id===net?'active':''}" data-net="${n.id}">${n.name}</button>`).join("")}
          </div>

          <div style="text-align:center">
            <div class="qr-big">
              <canvas id="recvQR" width="240" height="240"></canvas>
            </div>
          </div>

          <div style="text-align:center">
            <div style="font-size:13px;color:var(--text-secondary);font-weight:500">${w.ens} · ${sel.name}</div>
            <div class="t-mono" style="font-size:14px;font-weight:600;margin-top:6px;word-break:break-all">${UI.shortAddr(w.address,14,12)}</div>
          </div>

          <div class="push-bottom">
            <button class="btn btn-primary btn-block btn-pill" data-copy>Copy address</button>
            <button class="btn btn-secondary btn-block btn-pill" data-share style="margin-top:10px">Share</button>
          </div>
        </div>`,
      onMount: (view, close) => {
        const canvas = view.querySelector("#recvQR");
        UI.drawQR(canvas, w.address + "|" + net, 240);

        view.querySelectorAll("[data-net]").forEach(p => {
          p.addEventListener("click", () => {
            net = p.getAttribute("data-net");
            view.querySelectorAll("[data-net]").forEach(x => x.classList.toggle("active", x === p));
            const n = D.NETWORKS.find(x => x.id === net);
            const label = view.querySelector(".recv-net").nextElementSibling.nextElementSibling.querySelector("div");
            label.textContent = w.ens + " · " + n.name;
            UI.drawQR(canvas, w.address + "|" + net, 240);
          });
        });

        view.querySelector("[data-copy]").addEventListener("click", async () => {
          try { await navigator.clipboard.writeText(w.address); UI.toast("Address copied", "success"); }
          catch { try { window.prompt("Copy address:", w.address); } catch(e) {} }
        });
        view.querySelector("[data-share]").addEventListener("click", async () => {
          try { await navigator.clipboard.writeText(w.address); UI.toast("Link copied", "success"); }
          catch { try { window.prompt("Copy address:", w.address); } catch(e) {} }
        });
      }
    });
  }

  return { open };
})();

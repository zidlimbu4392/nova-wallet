import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { SwapSchema } from '@/lib/schemas';
import { authenticateRequest } from '@/lib/auth';

const prisma = new PrismaClient();

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  try {
    // Auth
    const auth = await authenticateRequest(request);
    if (!auth) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    // Parse & validate
    const body = await request.json();
    const parsed = SwapSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: 'Validation failed', details: parsed.error.flatten() }, { status: 400 });
    }
    const { fromTokenId, toTokenId, amount, slippage } = parsed.data;

    if (fromTokenId === toTokenId) {
      return NextResponse.json({ error: 'Cannot swap same token' }, { status: 400 });
    }

    // Get tokens and balance
    const [fromToken, toToken, fromBalance] = await Promise.all([
      prisma.token.findUnique({ where: { id: fromTokenId } }),
      prisma.token.findUnique({ where: { id: toTokenId } }),
      prisma.walletBalance.findUnique({
        where: { userId_tokenId: { userId: auth.userId, tokenId: fromTokenId } }
      })
    ]);

    if (!fromToken || !toToken) {
      return NextResponse.json({ error: 'Token not found' }, { status: 404 });
    }
    if (!fromBalance || fromBalance.balance < amount) {
      return NextResponse.json({ error: 'Insufficient balance' }, { status: 400 });
    }

    // Calculate swap
    const rate = fromToken.priceUsd / (toToken.priceUsd || 1);
    const receiveAmount = parseFloat((amount * rate * (1 - slippage / 100)).toFixed(6));
    const fiatValue = parseFloat((amount * fromToken.priceUsd).toFixed(2));
    const fee = parseFloat((Math.random() * 1.5 + 0.1).toFixed(2));

    // Generate tx hash
    let hash = '0x';
    for (let i = 0; i < 64; i++) hash += Math.floor(Math.random() * 16).toString(16);

    // Execute in transaction: deduct from, add to, create tx record
    await prisma.$transaction([
      // Deduct fromToken
      prisma.walletBalance.update({
        where: { userId_tokenId: { userId: auth.userId, tokenId: fromTokenId } },
        data: { balance: { decrement: amount } }
      }),
      // Add toToken (upsert in case user has 0 balance / no record)
      prisma.walletBalance.upsert({
        where: { userId_tokenId: { userId: auth.userId, tokenId: toTokenId } },
        update: { balance: { increment: receiveAmount } },
        create: { userId: auth.userId, tokenId: toTokenId, balance: receiveAmount }
      }),
      // Create transaction record
      prisma.transaction.create({
        data: {
          userId: auth.userId,
          type: 'swap',
          tokenId: fromTokenId,
          amount,
          fiatValue,
          hash,
          fee,
          note: `${fromToken.symbol}→${toToken.symbol}`,
          status: 'success'
        }
      })
    ]);

    return NextResponse.json({
      success: true,
      swap: {
        from: { token: fromToken.symbol, amount },
        to: { token: toToken.symbol, amount: receiveAmount },
        rate: parseFloat(rate.toFixed(6)),
        fiat: fiatValue,
        fee,
        hash
      }
    });
  } catch (error) {
    console.error('Swap API Error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

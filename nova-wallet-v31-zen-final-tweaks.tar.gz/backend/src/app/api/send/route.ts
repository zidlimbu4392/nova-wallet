import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { SendSchema } from '@/lib/schemas';
import { authenticateRequest } from '@/lib/auth';

const prisma = new PrismaClient();

export const dynamic = 'force-dynamic';

export async function POST(request: Request) {
  try {
    // Auth
    const auth = await authenticateRequest(request);
    if (!auth) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    // Parse & validate
    const body = await request.json();
    const parsed = SendSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: 'Validation failed', details: parsed.error.flatten() }, { status: 400 });
    }
    const { tokenId, amount, toAddress } = parsed.data;

    // Check balance
    const balance = await prisma.walletBalance.findUnique({
      where: { userId_tokenId: { userId: auth.userId, tokenId } },
      include: { token: true }
    });
    if (!balance || balance.balance < amount) {
      return NextResponse.json({ error: 'Insufficient balance' }, { status: 400 });
    }

    // Calculate fee (realistic: 0.1-2% of token value)
    const fee = parseFloat((Math.random() * 1.5 + 0.1).toFixed(2));
    const fiatValue = parseFloat((amount * balance.token.priceUsd).toFixed(2));

    // Generate tx hash
    let hash = '0x';
    for (let i = 0; i < 64; i++) hash += Math.floor(Math.random() * 16).toString(16);

    // Execute in transaction
    const [updatedBalance, tx] = await prisma.$transaction([
      prisma.walletBalance.update({
        where: { userId_tokenId: { userId: auth.userId, tokenId } },
        data: { balance: { decrement: amount } }
      }),
      prisma.transaction.create({
        data: {
          userId: auth.userId,
          type: 'send',
          tokenId,
          amount,
          fiatValue,
          toAddress,
          hash,
          fee,
          status: 'success'
        }
      })
    ]);

    return NextResponse.json({
      success: true,
      transaction: {
        id: tx.id,
        type: 'send',
        token: balance.token.symbol,
        amount,
        fiat: fiatValue,
        hash,
        fee,
        status: 'success'
      },
      newBalance: updatedBalance.balance
    });
  } catch (error) {
    console.error('Send API Error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
